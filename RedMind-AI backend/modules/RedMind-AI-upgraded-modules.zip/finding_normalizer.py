def normalize_findings(findings, target, check_id):
    normalized = []

    for f in findings:
        item = dict(f)

        endpoint = item.get("endpoint", "")
        payload = item.get("payload", "")
        param = item.get("parameter", endpoint)

        item.setdefault(
            "issue",
            item.get("name", f"{check_id} Security Finding")
        )

        item.setdefault(
            "parameter",
            param
        )

        item.setdefault(
            "payload",
            payload
        )

        item.setdefault(
            "url",
            item.get("url", target.rstrip("/") + endpoint if endpoint else target)
        )

        item.setdefault(
            "evidence",
            item.get("response", item.get("proof", ""))
        )

        item.setdefault(
            "confidence",
            "MEDIUM"
        )

        item.setdefault(
            "description",
            f"{check_id} detected a potential security issue."
        )

        item.setdefault(
            "remediation",
            "Review the affected component and apply appropriate security controls."
        )

        item.setdefault(
            "references",
            []
        )

        normalized.append(item)

    return normalized
