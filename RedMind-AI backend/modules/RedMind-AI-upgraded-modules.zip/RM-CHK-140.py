from finding_normalizer import normalize_findings

import requests
import time

def run(target, timeout=15, dangerous=False):
    results = []
    headers = {
        "User-Agent": "RedMind-AI-VAPT/1.0",
        "Accept": "*/*"
    }


    try:
        r = requests.post(target, headers=headers, timeout=timeout)
        if r.status_code == 200:
            results.append({
                "issue": "Method tampering",
                "confidence": "LOW"
            })
    except Exception:
        pass


    return {
        "check_id": "RM-CHK-140",
        "severity": "MEDIUM",
        "target": target,
        "dangerous": dangerous,
        "findings": normalize_findings(results, target, "RM-CHK-140"),
        "summary": {
            "tested_requests": len(results),
            "positive_hits": len(results)
        }
    }
